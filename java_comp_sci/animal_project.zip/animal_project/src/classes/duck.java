package classes;

public class duck extends animal implements can_float, can_fly, can_swim, can_walk, can_run {

    public duck() {
        name = "duck";
        weight = 5;
    }
    
}
