package interfaces;

public class can_float {
    
}
